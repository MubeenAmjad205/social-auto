/**
 * src/instagram.ts — token refresh + container publishing. (v1.1)
 *
 * Counterintuitively, Instagram is the EASIER platform to keep running:
 * its token refreshes itself forever with no human involvement, unlike
 * LinkedIn's. It is the harder one to get started on — app review is 2-4 weeks.
 */

import type { Env } from './index';
import type { Store, Draft } from './store';

const GRAPH = 'https://graph.instagram.com';

/**
 * Fully automatic. The token must be >24h old; each refresh resets it to 60
 * days from now. Run nightly and unconditionally — there is no penalty for
 * refreshing early, and letting it lapse means a full manual re-auth.
 */
export async function refreshInstagramToken(env: Env, store: Store) {
  const tok = await store.getToken('instagram');
  if (!tok) throw new Error('no Instagram token seeded');
  if (Date.now() - +tok.updated_at < 86_400_000) return; // must be >24h old

  const res = await fetch(
    `${GRAPH}/refresh_access_token?grant_type=ig_refresh_token&access_token=${tok.access_token}`
  );
  if (!res.ok) throw new Error(`refresh ${res.status}: ${await res.text()}`);

  const { access_token, expires_in } = await res.json<{ access_token: string; expires_in: number }>();
  await store.saveToken('instagram', {
    access_token,
    expires_at: new Date(Date.now() + expires_in * 1000),
  });
}

/**
 * Three-step container flow. Instagram will NOT accept file bytes — it cURLs
 * the URL you give it. That is why the R2 bucket must be publicly readable and
 * not blocked by robots.txt.
 */
export async function publishInstagram(env: Env, store: Store, draft: Draft): Promise<string> {
  const tok = await store.getToken('instagram');
  if (!tok) throw new Error('no Instagram token');

  // Meta's own docs give both 100 and 50 on the same page, and the widely
  // quoted 25 appears in neither. Query the endpoint instead of hardcoding.
  const limit: any = await fetch(
    `${GRAPH}/${env.IG_USER_ID}/content_publishing_limit?access_token=${tok.access_token}`
  ).then(r => r.json()).catch(() => null);

  const used = limit?.data?.[0]?.quota_usage ?? 0;
  const cap = limit?.data?.[0]?.config?.quota_total ?? 25;
  if (used >= cap) throw new Error(`IG publish quota exhausted (${used}/${cap})`);

  // 1. Create the container.
  const create = await fetch(`${GRAPH}/v23.0/${env.IG_USER_ID}/media`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      image_url: `${env.PUBLIC_R2_BASE}/${draft.image_key}`,
      caption: draft.body,
      access_token: tok.access_token,
    }),
  });
  if (!create.ok) throw new Error(`container ${create.status}: ${await create.text()}`);
  const { id: creationId } = await create.json<{ id: string }>();

  // 2. Poll until FINISHED. Publishing early returns a bare 400 with no hint.
  //    Cron Triggers get 15 minutes of wall time, so this is safe here.
  for (let i = 0; i < 5; i++) {
    const st = await fetch(
      `${GRAPH}/${creationId}?fields=status_code&access_token=${tok.access_token}`
    ).then(r => r.json<{ status_code: string }>());

    if (st.status_code === 'FINISHED') break;
    if (st.status_code === 'ERROR' || st.status_code === 'EXPIRED') {
      throw new Error(`container ${st.status_code}`);
    }
    await new Promise(r => setTimeout(r, 20_000));
  }

  // 3. Publish. Containers expire after 24h — never split this across runs.
  const pub = await fetch(`${GRAPH}/v23.0/${env.IG_USER_ID}/media_publish`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ creation_id: creationId, access_token: tok.access_token }),
  });
  if (!pub.ok) throw new Error(`publish ${pub.status}: ${await pub.text()}`);

  const { id } = await pub.json<{ id: string }>();
  return id;
}
