/**
 * src/telegram.ts — the approval gate and the entire user interface.
 *
 * This is the single most valuable component in the system. It is the
 * difference between a drafting assistant and an autopilot that publishes a
 * hallucinated statistic under your own name at 4am.
 */

import type { Env } from './index';

const api = (env: Env, method: string) =>
  `https://api.telegram.org/bot${env.TELEGRAM_BOT_TOKEN}/${method}`;

export async function notify(env: Env, text: string) {
  await fetch(api(env, 'sendMessage'), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      chat_id: env.TELEGRAM_CHAT_ID,
      text,
      parse_mode: 'Markdown',
      disable_web_page_preview: true,
    }),
  });
}

export async function sendDraftForApproval(
  env: Env,
  d: { id: string; platform: string; body: string; flags: string[]; sourceCount: number; imageUrl: string }
) {
  // Editor flags are surfaced, never auto-applied. You decide.
  const header = d.flags.length
    ? d.flags.map(f => `⚠️ ${f}`).join('\n') + '\n\n'
    : '';

  const provenance = d.sourceCount > 0
    ? `\n\n_grounded in ${d.sourceCount} source(s)_`
    : `\n\n_seed-only — no external claims_`;

  await fetch(api(env, 'sendPhoto'), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      chat_id: env.TELEGRAM_CHAT_ID,
      photo: d.imageUrl,
      caption: `${header}*${d.platform}*\n\n${d.body}${provenance}`.slice(0, 1024),
      parse_mode: 'Markdown',
      reply_markup: {
        inline_keyboard: [[
          { text: '✅ Approve', callback_data: `ok:${d.id}` },
          { text: '🎲 Redraw',  callback_data: `redraw:${d.id}` },
          { text: '🗑 Reject',  callback_data: `no:${d.id}` },
        ]],
      },
    }),
  });
}

export async function handleTelegramWebhook(request: Request, env: Env): Promise<Response> {
  const update = await request.json<any>();
  const { storeFor } = await import('./index');
  const store = storeFor(env);

  try {
    // ---- button taps
    if (update.callback_query) {
      const cb = update.callback_query;
      const [action, draftId] = String(cb.data).split(':');

      if (action === 'redraw') {
        // Regenerating is cheap: ~104 neurons of a 10,000/day allowance.
        // You can reject an image ninety times a day and pay nothing.
        await store.clearImage(draftId);
      } else {
        await store.setStatus(draftId, action === 'ok' ? 'approved' : 'rejected');
      }

      await fetch(api(env, 'answerCallbackQuery'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          callback_query_id: cb.id,
          text: action === 'ok' ? 'Queued for the next publish run' : action,
        }),
      });
      return new Response('ok');
    }

    // ---- /seed — the one input only you can provide
    const text: string = update.message?.text ?? '';
    if (text.startsWith('/seed')) {
      const rest = text.replace(/^\/seed\s*/, '').trim();
      const isClient = rest.startsWith('client ');
      const note = isClient ? rest.slice(7).trim() : rest;

      if (!note) {
        await notify(env, 'Usage:\n`/seed <what happened>`\n`/seed client <what happened>`');
      } else {
        await store.addSeed(note, isClient ? 'client' : 'own');
        const n = await store.seedCount();
        await notify(env, `🌱 Seed banked (${isClient ? 'client' : 'own'}). ${n} in the queue.`);
      }
      return new Response('ok');
    }

    if (text.startsWith('/status')) {
      const n = await store.seedCount();
      await notify(env, `🌱 ${n} unused seed(s) in the queue.`);
    }

    return new Response('ok');
  } finally {
    await store.close();
  }
}
